#include<stdio.h>
int main()
{
    int ar[10];
    return 0;
}