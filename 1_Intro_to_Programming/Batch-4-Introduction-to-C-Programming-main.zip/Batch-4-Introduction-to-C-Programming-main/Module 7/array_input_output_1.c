#include<stdio.h>
int main()
{
    int ar[5000];
    // ar[0], ar[1], ar[2]
    ar[0]=100;
    ar[1]=200;
    ar[2]=500;

    printf("%d %d %d",ar[0],ar[1],ar[2]);
    return 0;
}