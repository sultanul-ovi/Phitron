#include<stdio.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    // double x;
    // scanf("%lf",&x);
    // int ans=ceil(x);
    // int ans=floor(x);
    // int ans=round(x);

    // double x;
    // scanf("%lf",&x);
    // double ans=sqrt(x);
    // printf("%0.2lf",ans);

    // int a,b;
    // scanf("%d %d",&a,&b);
    // int ans=pow(a*1.0,b*1.0);
    // printf("%d\n",ans);

    int x;
    scanf("%d",&x);
    int ans=abs(x);
    printf("%d",ans);
    return 0;
}