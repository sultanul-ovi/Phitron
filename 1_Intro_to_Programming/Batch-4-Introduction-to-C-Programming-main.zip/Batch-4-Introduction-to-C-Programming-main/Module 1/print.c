#include <stdio.h>
int main()
{
    // printf("Hello\tHi I am a programmer");

    printf("100%%%%");
    return 0;
}

// Hello
// Hi I am a programmer

// Special characters (ESCAPE)
// \n - new line
// \t - tab
