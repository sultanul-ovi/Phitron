#include <stdio.h>
int main()
{
    // int rahim = 100, karim = 200;
    // printf("%d %d", karim, rahim);

    // float chol = 2.557;
    // printf("%0.4f", chol);

    char ami = 'K';
    printf("%c", ami);
    return 0;
}