#include <stdio.h>
int main()
{
    int a = 3, b = 20;
    int mod = a % b;
    printf("%d", mod);
    return 0;
}
// + - * / %
// a + b
// a - b
// a * b
// a / b -> 5/2 - > int ans = a*1.0/2
// a % b
