#include <stdio.h>
int main()
{
    int tk;
    scanf("%d", &tk);
    if (tk >= 1000)
    {
        printf("Ami pizza khabo\n");
        printf("Ami ghurte jabo\n");
    }

    return 0;
}