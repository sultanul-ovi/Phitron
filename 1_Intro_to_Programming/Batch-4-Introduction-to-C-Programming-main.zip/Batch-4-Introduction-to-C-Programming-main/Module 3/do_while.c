#include<stdio.h>
int main()
{
    int i;

    // do while
    i=1;
    do 
    {
        printf("%d\n",i);
        i=i+1;
    }
    while(i<=5);
    return 0;
}