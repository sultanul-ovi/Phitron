#include<stdio.h>
int main()
{
    for(int i=1;i<=10;i++)
    {
        // kaj
        for(int j=1;j<=5;j++)
        {
            printf("%d ",j);
        }
        printf("\n");
    }
    return 0;
}